// /js/star.js — Stelle interattive per la valutazione numerica

document.addEventListener("DOMContentLoaded", () => {

	// Seleziona tutti i contenitori con classe .rating-input
	document.querySelectorAll(".rating-input").forEach((container) => {

		// Trova le stelle all'interno del contenitore
		const stars = Array.from(container.querySelectorAll(".star"));

		// Trova l'input hidden associato (es. name="voto")
		const hidden = container.parentElement.querySelector("input[name='voto']");
		if (!hidden) return; // Se non c'è input nascosto, esci

		// === Imposta lo stato iniziale ===
		// Serve per pre-compilare il valore in caso di modifica
		paint(+hidden.value || 0);

		// === Gestione eventi su ogni stella ===
		stars.forEach((star) => {

			// Al click: aggiorna il valore dell’input e colora le stelle
			star.addEventListener("click", () => {
				const v = +star.dataset.value;
				hidden.value = v;
				paint(v);
			});

			// Al passaggio del mouse: mostra effetto "hover" (anteprima voto)
			star.addEventListener("mouseenter", () => {
				paint(+star.dataset.value);
			});
		});

		// Quando il mouse esce dal contenitore, ripristina il voto attuale
		container.addEventListener("mouseleave", () => {
			paint(+hidden.value || 0);
		});

		// === Funzione per colorare le stelle in base al valore (v) ===
		function paint(v) {
			stars.forEach((s, i) => {
				s.classList.toggle("selected", i < v); // Aggiunge classe 'selected' fino alla stella selezionata
			});
		}
	});
});