// /static/js/toolbar.js — Gestione dinamica della toolbar dei filtri

document.addEventListener('DOMContentLoaded', () => {

  // ===================================================
  // 1) Tendina "Seleziona genere" nella toolbar (HOME)
  // ===================================================

  document.querySelectorAll('details.toolbar-genres').forEach(genres => {
    const summary = genres.querySelector('summary'); // Titolo visibile del <details>
    const checks  = genres.querySelectorAll('input[type="checkbox"][name="genereId"]'); // Checkbox dei generi
    const DEFAULT = (
      summary?.dataset?.defaultLabel || summary?.textContent || 'Seleziona genere'
    ).trim(); // Etichetta predefinita

    // Funzione che aggiorna il testo del summary con i generi selezionati
    function updateSummary() {
      const sel = Array.from(checks)
        .filter(c => c.checked) // Filtra solo i checkbox selezionati
        .map(c => (c.nextElementSibling?.textContent || '').trim()) // Prende il testo accanto al checkbox
        .filter(Boolean); // Rimuove eventuali stringhe vuote

      summary.textContent =
        sel.length === 0 ? DEFAULT :                 // Nessuna selezione → testo predefinito
        sel.length <= 3 ? sel.join(', ') :           // Fino a 3 generi → elenco
        `${sel.length} generi`;                      // Più di 3 generi → mostra solo il numero
    }

    // Aggiorna il summary ogni volta che un checkbox cambia stato
    checks.forEach(c => c.addEventListener('change', updateSummary));

    // Stato iniziale
    updateSummary();
  });


  // ===================================================
  // 2) Pannello "Filtra per" (nelle pagine di ricerca/index)
  // ===================================================

  const panel = document.getElementById('filtersPanel');
  if (panel) {
    const summary = panel.querySelector('summary.filters-toggle'); // Titolo del pannello
    const checks = panel.querySelectorAll('input[name="genereId"]'); // Checkbox dei generi
    const DEFAULT = 'Filtra per'; // Testo di default

    // Aggiorna il testo del summary con il numero di filtri attivi
    function refresh() {
      const sel = Array.from(checks).filter(c => c.checked).length;
      if (summary) {
        summary.textContent = sel ? `Filtri (${sel})` : DEFAULT;
      }
    }

    // Aggiorna il summary quando i checkbox cambiano
    checks.forEach(c => c.addEventListener('change', refresh));

    // Stato iniziale
    refresh();
  }


  // ===================================================
  // 3) Comportamento globale dei <details>:
  //    - Chiude i pannelli aperti cliccando fuori
  //    - Chiude i pannelli con ESC
  // ===================================================

  // Clic fuori da un <details> → chiude tutti gli altri
  document.addEventListener('click', (e) => {
    const clickedDetails = e.target.closest('details'); // Pannello cliccato (se esiste)
    document.querySelectorAll('details[open]').forEach(d => {
      if (d !== clickedDetails) {
        d.removeAttribute('open');
      }
    });
  });

  // Premendo ESC → chiude tutti i <details> aperti
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('details[open]').forEach(d => d.removeAttribute('open'));
    }
  });

});