// extra.js — micro-migliorie UI non invasive (SENZA ricerca dinamica)

document.addEventListener('DOMContentLoaded', () => {

  // === 1) Effetto "reveal" delle card quando entrano nel viewport ===
  const cards = document.querySelectorAll('.grid .card');
  if ('IntersectionObserver' in window && cards.length) {
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) {
        if (e.isIntersecting) {
          e.target.classList.add('is-visible'); // Mostra la card
          io.unobserve(e.target); // Smette di osservarla dopo la prima volta
        }
      }
    }, {
      rootMargin: '0px 0px -10% 0px', // Inizia a mostrare leggermente prima
      threshold: 0.2 // Percentuale di visibilità minima
    });

    cards.forEach(c => {
      c.classList.add('reveal-card'); // Classe iniziale
      io.observe(c); // Inizio osservazione
    });
  }

  // === 2) Ricerca live front-end rimossa ===
  // Nessun listener su input[name="elementoRicerca"].
  // La ricerca avviene solo al submit (es. Enter o bottone).

  // === 3) Menu utente a tendina sull'avatar ===
  const userHeader = document.querySelector('.user-header');
  if (userHeader) {
    const img = userHeader.querySelector('.user-photo');
    const username = userHeader.querySelector('.username')?.textContent || 'Profilo';

    // Crea il menu solo se non esiste già
    if (img && !userHeader.querySelector('.user-menu')) {
      const menu = document.createElement('div');
      menu.className = 'user-menu';
      menu.innerHTML = `
        <a class="user-menu__item" href="${img.parentElement?.getAttribute('href') || '#'}">👤 ${username}</a>
        <form class="user-menu__item" method="post" action="/logout">
          <button type="submit">🚪 Logout</button>
        </form>
      `;
      menu.hidden = true; // Nascondi menu inizialmente
      userHeader.style.position = 'relative';
      userHeader.appendChild(menu);

      // Mostra/Nasconde il menu cliccando l'immagine
      img.style.cursor = 'pointer';
      img.addEventListener('click', (e) => {
        e.preventDefault();
        menu.hidden = !menu.hidden;
      });

      // Chiude il menu cliccando fuori o premendo ESC
      document.addEventListener('click', (e) => {
        if (!userHeader.contains(e.target)) menu.hidden = true;
      });
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') menu.hidden = true;
      });
    }
  }

  // === 4) Bottone "torna su" visibile dopo scroll + scroll morbido ===
  const backTop = document.createElement('button');
  backTop.className = 'back-to-top';
  backTop.type = 'button';
  backTop.title = 'Torna su';
  backTop.textContent = '↑';

  // Al click, torna all’inizio della pagina
  backTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  document.body.appendChild(backTop);

  // Mostra o nasconde il bottone in base allo scroll
  const onScroll = () => {
    backTop.classList.toggle('is-visible', window.scrollY > 400);
  };

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll(); // Esegue subito per verificare lo stato iniziale

  // === 5) Ricorda solo l’ordinamento selezionato in localStorage ===
  const form = document.querySelector('form.filters-nav');
  const ORDER_NAME = 'filtroApplicato';

  try {
    const orderSel = form?.querySelector(`select[name="${ORDER_NAME}"]`);
    const savedOrder = localStorage.getItem('cc_order') || '';

    // Se esiste un valore salvato, applicalo
    if (orderSel && !orderSel.value && savedOrder) {
      orderSel.value = savedOrder;
    }

    // Aggiorna localStorage al cambio selezione
    orderSel?.addEventListener('change', () => {
      localStorage.setItem('cc_order', orderSel.value);
    });

    // Rimuove il valore salvato al reset del form
    form?.addEventListener('reset', () => {
      localStorage.removeItem('cc_order');
    });

  } catch {
    // Se localStorage non è disponibile, ignora senza errori
  }
});


// === Stelle interattive per il voto nella pagina recensione ===
(() => {
  const form = document.querySelector('form[action^="/recensioni/film/"]');
  if (!form) return;

  const number = form.querySelector('input[type="number"][name="voto"]');
  if (!number) return;

  // Crea container per le stelle
  const starWrap = document.createElement('div');
  starWrap.className = 'stars';

  // Aggiunge 5 stelle (☆)
  for (let i = 1; i <= 5; i++) {
    const s = document.createElement('button');
    s.type = 'button';
    s.className = 'star';
    s.dataset.value = i;
    s.textContent = '☆';
    starWrap.appendChild(s);
  }

  // Nasconde il campo numerico
  number.insertAdjacentElement('beforebegin', starWrap);
  number.style.display = 'none';

  // Funzione per "colorare" le stelle in base al voto
  const paint = (val) => {
    starWrap.querySelectorAll('.star').forEach(b => {
      b.textContent = (+b.dataset.value <= val) ? '★' : '☆';
    });
  };

  // Imposta lo stato iniziale
  paint(+number.value || 0);

  // Clic su una stella: aggiorna valore e colore
  starWrap.addEventListener('click', (e) => {
    const btn = e.target.closest('.star');
    if (!btn) return;
    number.value = btn.dataset.value;
    paint(+number.value);
  });

  // Passaggio del mouse sopra le stelle (preview)
  starWrap.addEventListener('mousemove', (e) => {
    const btn = e.target.closest('.star');
    if (btn) paint(+btn.dataset.value);
  });

  // Quando il mouse esce, torna al voto salvato
  starWrap.addEventListener('mouseleave', () => {
    paint(+number.value || 0);
  });
})();