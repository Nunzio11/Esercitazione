drop schema libreria_film;

create schema libreria_film;

use libreria_film;



CREATE TABLE attore (
    id BIGINT NOT NULL AUTO_INCREMENT,
    foto TEXT,
    nome VARCHAR(45) NOT NULL,
    cognome VARCHAR(45) NOT NULL,
    biografia TEXT,
    PRIMARY KEY (id)
);

CREATE TABLE genere (
    id BIGINT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(45) NOT NULL UNIQUE,
    PRIMARY KEY (id)
);

CREATE TABLE regista (
    id BIGINT NOT NULL AUTO_INCREMENT,
    foto TEXT,
    nome VARCHAR(45) NOT NULL,
    cognome VARCHAR(45) NOT NULL,
    biografia TEXT,
    PRIMARY KEY (id)
);

CREATE TABLE film (
    id BIGINT NOT NULL AUTO_INCREMENT,
    foto TEXT NOT NULL,
    titolo TEXT NOT NULL,
    trama TEXT NOT NULL,
    durata INT NOT NULL,
    anno_uscita INT NOT NULL,
    pg INT NOT NULL,
    regista_id BIGINT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (regista_id)
        REFERENCES regista (id)
);

CREATE TABLE film_attore (
    id BIGINT NOT NULL AUTO_INCREMENT,
    film_id BIGINT NOT NULL,
    attore_id BIGINT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (film_id)
        REFERENCES film (id),
    FOREIGN KEY (attore_id)
        REFERENCES attore (id)
);

CREATE TABLE film_genere (
    id BIGINT NOT NULL AUTO_INCREMENT,
    film_id BIGINT NOT NULL ,
    genere_id BIGINT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (film_id)
        REFERENCES film (id),
    FOREIGN KEY (genere_id)
        REFERENCES genere (id)
);
/*
CREATE TABLE utente (
    id BIGINT NOT NULL AUTO_INCREMENT,
    username VARCHAR(45) NOT NULL,
    psw VARCHAR(45) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE recensione_film (
    id BIGINT NOT NULL AUTO_INCREMENT,
    commento TEXT,
    voto INT NOT NULL,
    film_id BIGINT NOT NULL UNIQUE,
    utente_id BIGINT NOT NULL UNIQUE,
    PRIMARY KEY (id),
    FOREIGN KEY (film_id)
        REFERENCES film (id),
    FOREIGN KEY (utente_id)
        REFERENCES utente (id)
);
*/