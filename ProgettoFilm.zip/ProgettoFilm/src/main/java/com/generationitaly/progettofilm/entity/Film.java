package com.generationitaly.progettofilm.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity // Indica che questa classe è una entità JPA (verrà mappata su una tabella)
@Table(name = "film") // Specifica il nome della tabella nel database: "film"
public class Film {

	@Id // Identifica il campo come chiave primaria
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Generazione automatica del valore (auto-incremento)
	@Column(name = "id") // Mappa la variabile al campo "id" della tabella
	private long id;

	@Column(name = "foto", nullable = true) // Colonna "foto", può essere nulla
	private String foto;

	@Column(name = "titolo", nullable = false) // Colonna "titolo", obbligatoria
	private String titolo;

	@Column(name = "trama", nullable = true, length = 15000) // Colonna "trama", opzionale, max 15000 caratteri
	private String trama;

	@Column(name = "durata", nullable = false) // Colonna "durata" in minuti, obbligatoria
	private int durata;

	@Column(name = "anno_uscita", nullable = false) // Colonna "anno_uscita", obbligatoria
	private int annoUscita;

	@Column(name = "pg", nullable = false) // Colonna "pg" (età consigliata), obbligatoria
	private int pg;

	@Column(name = "trailer") // Colonna "trailer" per il link YouTube, opzionale
	private String trailer;

	@ManyToOne // Relazione molti-a-uno: molti film hanno un solo regista
	@JoinColumn(name = "regista_id") // Colonna "regista_id" come chiave esterna nella tabella "film"
	private Regista regista;

	@OneToMany(mappedBy = "film", fetch = FetchType.EAGER) // Uno-a-molti con FilmAttore, caricamento immediato
	private List<FilmAttore> filmAttore; // Lista di associazioni con attori

	@OneToMany(mappedBy = "film", fetch = FetchType.EAGER) // Uno-a-molti con FilmGenere, caricamento immediato
	private List<FilmGenere> filmGenere; // Lista di generi associati

	@OneToMany(mappedBy = "film", fetch = FetchType.EAGER) // Uno-a-molti con RecensioneFilm
	private List<RecensioneFilm> recensioni; // Lista di recensioni legate a questo film

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public String getTrama() {
		return trama;
	}

	public void setTrama(String trama) {
		this.trama = trama;
	}

	public int getDurata() {
		return durata;
	}

	public void setDurata(int durata) {
		this.durata = durata;
	}

	public int getAnnoUscita() {
		return annoUscita;
	}

	public void setAnnoUscita(int annoUscita) {
		this.annoUscita = annoUscita;
	}

	public int getPg() {
		return pg;
	}

	public void setPg(int pg) {
		this.pg = pg;
	}

	public Regista getRegista() {
		return regista;
	}

	public void setRegista(Regista regista) {
		this.regista = regista;
	}

	public String getTrailer() {
		return trailer;
	}

	public void setTrailer(String trailer) {
		this.trailer = trailer;
	}

	public List<FilmAttore> getFilmAttore() {
		return filmAttore;
	}

	public void setFilmAttore(List<FilmAttore> filmAttore) {
		this.filmAttore = filmAttore;
	}

	public List<FilmGenere> getFilmGenere() {
		return filmGenere;
	}

	public void setFilmGenere(List<FilmGenere> filmGenere) {
		this.filmGenere = filmGenere;
	}

	public List<RecensioneFilm> getRecensioni() {
		return recensioni;
	}

	public void setRecensioni(List<RecensioneFilm> recensioni) {
		this.recensioni = recensioni;
	}

	@Override
	public String toString() {
		return "Film [id=" + id + ", foto=" + foto + ", titolo=" + titolo + ", trama=" + trama + ", durata=" + durata
				+ ", annoUscita=" + annoUscita + ", pg=" + pg + "]";
	}

}
