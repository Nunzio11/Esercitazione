package com.generationitaly.progettofilm.dto;

import com.generationitaly.progettofilm.entity.Utente;

import jakarta.validation.constraints.NotBlank;

public class RegistDto {
	
	@NotBlank(message =" Campo Obbligatorio")
    private String username;

	@NotBlank(message =" Campo Obbligatorio")
	private String nome;
	
	@NotBlank(message =" Campo Obbligatorio")
    private String cognome;
	
	@NotBlank(message =" Campo Obbligatorio")
    private String email;

	@NotBlank(message =" Campo Obbligatorio")
	private String password;
	
	private String foto;

     
	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Utente toEntity() {

		Utente utente = new Utente();
		utente.setFoto(this.foto);
		utente.setNome(this.nome);
		utente.setCognome(this.cognome);
		utente.setUsername(this.username);
		utente.setEmail(this.email);
		utente.setPassword(this.password);
		return utente;

	}

}
