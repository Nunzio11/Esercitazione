package com.generationitaly.progettofilm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.generationitaly.progettofilm.entity.Utente;

public interface UtenteRepository extends JpaRepository<Utente, Long>{

	Utente findByUsername(String username);

}
