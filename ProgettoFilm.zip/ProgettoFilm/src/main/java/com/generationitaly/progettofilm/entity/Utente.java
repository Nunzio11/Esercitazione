package com.generationitaly.progettofilm.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

/*
CREATE TABLE utente (
	    id BIGINT NOT NULL AUTO_INCREMENT,
	    username VARCHAR(255) NOT NULL,
	    email VARCHAR(255),
	    pssw VARCHAR(255) NOT NULL,
	    PRIMARY KEY (id)
	);*/
@Entity // Indica che questa classe è una entità JPA, mappata su una tabella del database
@Table(name = "utente") // Specifica il nome della tabella nel database (utente)
public class Utente {
    
    @Id // Chiave primaria della tabella
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    // L'id è generato automaticamente dal database (auto-increment)
    @Column(name = "id")
    private Long id;

    // COMMENTO: Non aggiungere la proprietà 'length' ai campi String,
    // perché SQL di default imposta VARCHAR(255), e qui la lunghezza è gestita diversamente.

    @Column(name = "foto", length = 15000)
    // Colonna "foto", può contenere fino a 15000 caratteri (es. URL o immagine in base64)
    private String foto;
    
    @Column(name = "nome")
    // Colonna "nome" (default VARCHAR(255))
    private String nome;

    @Column(name = "cognome")
    // Colonna "cognome" (default VARCHAR(255))
    private String cognome;

    @Column(name = "username")
    // Colonna "username" (default VARCHAR(255))
    private String username;

    @Column(name = "email", nullable = false)
    // Colonna "email", obbligatoria (non null)
    private String email;

    @Column(name = "password", nullable = false)
    // Colonna "password", obbligatoria (non null)
    private String password;

    @OneToMany(mappedBy = "utente", fetch = FetchType.EAGER)
    // Relazione uno a molti: un utente può avere molte recensioni di film
    // "mappedBy" indica che la proprietà "utente" è definita nella classe RecensioneFilm
    // FetchType.EAGER carica subito tutte le recensioni dell'utente
    private List<RecensioneFilm> recensioniUtente;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<RecensioneFilm> getRecensioniUtente() {
		return recensioniUtente;
	}

	public void setRecensioniUtente(List<RecensioneFilm> recensioniUtente) {
		this.recensioniUtente = recensioniUtente;
	}

	@Override
	public String toString() {
		return "Utente [id=" + id + ", foto=" + foto + ", nome=" + nome + ", cognome=" + cognome + ", username="
				+ username + ", email=" + email + ", password=" + password + "]";
	}

	

}
