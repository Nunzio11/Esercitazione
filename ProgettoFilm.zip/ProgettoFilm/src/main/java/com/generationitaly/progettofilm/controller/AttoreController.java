package com.generationitaly.progettofilm.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.generationitaly.progettofilm.entity.Attore;
import com.generationitaly.progettofilm.entity.Film;
import com.generationitaly.progettofilm.repository.AttoreRepository;
import com.generationitaly.progettofilm.repository.FilmRepository;

@Controller
public class AttoreController {
	
	// Iniezione automatica del repository degli attori
	@Autowired
	private AttoreRepository attoreRepository;
	
	// Iniezione automatica del repository dei film
	@Autowired
	FilmRepository filmRepository;
	
	// Mapping della rotta GET per mostrare i dettagli di un attore
	// Esempio URL: /info/attore/3
	@GetMapping(path="/info/attore/{attoreID}")
	public String mostraInfoAttore(@PathVariable("attoreID") Long id, Model model) {
		
		// Recupera l'attore dal database usando l'ID passato nell'URL
		// Se non viene trovato, restituisce null
		Attore attore = attoreRepository.findById(id).orElse(null);
		
		// Recupera la lista di film associati all'attore tramite l'ID
		List<Film> films = filmRepository.findFilmByAttore(id);
				
		// Aggiunge la lista dei film al model, con il nome "listaFilmDiATTORE"
		// Questo oggetto sarà disponibile nel file HTML (es. Thymeleaf)
		model.addAttribute("listaFilmDiATTORE", films);

		// Aggiunge l'attore al model con il nome "attore"
		model.addAttribute("attore", attore);
		
		// Ritorna il nome della vista da mostrare all'utente (es. "attoreDettaglio.html")
		return "attoreDettaglio";
	}

}
