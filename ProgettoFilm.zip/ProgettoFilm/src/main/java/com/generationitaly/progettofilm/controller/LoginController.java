package com.generationitaly.progettofilm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.generationitaly.progettofilm.dto.LoginDto;
import com.generationitaly.progettofilm.entity.Utente;
import com.generationitaly.progettofilm.repository.UtenteRepository;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class LoginController {

	@Autowired
	private UtenteRepository utenteRepository; // Inietta il repository per accedere ai dati degli utenti dal DB

	@GetMapping(path = "/login")
	public String showLoginForm(Model model) {
		model.addAttribute("loginDto", new LoginDto()); // Aggiunge un oggetto vuoto LoginDto al modello per il form
		return "login-utente"; // Ritorna la view "login-utente" (pagina di login)
	}

	@PostMapping(path = "/login")
	public String submitLoginForm(@Valid @ModelAttribute LoginDto loginDto, BindingResult bindingResult, Model model,
			HttpSession session) {

		if (bindingResult.hasErrors()) {
			return "login-utente"; // Se ci sono errori di validazione nel form, torna alla pagina login
		}
		Utente utente = utenteRepository.findByUsername(loginDto.getUsername()); // Cerca in DB l'utente con lo username
																					// fornito
		if (utente != null && utente.getPassword().equals(loginDto.getPassword())) { // Se utente esiste e password
																						// corrisponde
			session.setAttribute("utente", utente); // Salva l'oggetto utente in sessione (per tenerlo loggato)
			session.setAttribute("id", utente.getId()); // Salva in sessione anche l'id
			session.setAttribute("username", utente.getUsername()); // Username in sessione
			session.setAttribute("foto", utente.getFoto()); // Foto in sessione
			session.setAttribute("nome", utente.getNome()); // Nome in sessione
			session.setAttribute("cognome", utente.getCognome()); // Cognome in sessione

			return "redirect:/profilo/" + utente.getId(); // Reindirizza alla pagina profilo dell’utente
		} else {
			model.addAttribute("loginError", "Username o password errati"); // Aggiunge messaggio di errore nel modello
			return "login-utente"; // Torna alla pagina login con errore
		}
	}
}
