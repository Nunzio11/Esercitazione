package com.generationitaly.progettofilm;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import com.generationitaly.progettofilm.entity.Attore;
import com.generationitaly.progettofilm.entity.Film;
import com.generationitaly.progettofilm.entity.Genere;
import com.generationitaly.progettofilm.entity.Regista;
import com.generationitaly.progettofilm.repository.AttoreRepository;
import com.generationitaly.progettofilm.repository.FilmRepository;
import com.generationitaly.progettofilm.repository.RegistaRepository;

@SuppressWarnings("unused")  // Disabilita i warning del compilatore per variabili/metodi non usati, per evitare messaggi inutili
@SpringBootApplication            // Indica che questa classe è il punto di ingresso dell'app Spring Boot
public class ProgettoFilmApplication implements CommandLineRunner {  // Implementa CommandLineRunner per eseguire codice all'avvio

    @Autowired                   // Inietta automaticamente una dipendenza: qui un repository per Film
    private FilmRepository filmRepository;

    @Autowired                   // Inietta automaticamente un repository per Regista
    private RegistaRepository registaRepository;

    @Autowired                   // Inietta automaticamente un repository per Attore
    private AttoreRepository attoreRepository;

    // Qui andrà il metodo run() di CommandLineRunner che viene eseguito all'avvio
	
	public static void main(String[] args) {
		SpringApplication.run(ProgettoFilmApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
	
				
	}
	
	

}
