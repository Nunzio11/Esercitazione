package com.generationitaly.progettofilm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.generationitaly.progettofilm.entity.Regista;
import com.generationitaly.progettofilm.repository.RegistaRepository;

@Controller
public class RegistaController {

	@Autowired
	private RegistaRepository registaRepository;

	@GetMapping(path = "/info/regista/{registaId}")
	public String showRegistaINFO(@PathVariable("registaId") Long id, Model model) {
		 // Cerca un regista nel database usando l'id passato nella URL
        Regista regista = registaRepository.findById(id).orElse(null);

        // Aggiunge l'oggetto regista al Model, così sarà disponibile nella view
        model.addAttribute("regista", regista);

        // Restituisce il nome della pagina (view) da mostrare, in questo caso infoRegista.html
        return "infoRegista";
    }

}
