package com.generationitaly.progettofilm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.generationitaly.progettofilm.entity.Film;
import com.generationitaly.progettofilm.entity.RecensioneFilm;
import com.generationitaly.progettofilm.entity.Utente;
import com.generationitaly.progettofilm.repository.FilmRepository;
import com.generationitaly.progettofilm.repository.RecensioneFilmRepository;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/recensioni")
public class RecensioneFilmController {

	@Autowired
	private RecensioneFilmRepository recensioneRepo;

	@Autowired
	private FilmRepository filmRepo;

	@PostMapping("/film/{filmId}")
	public String aggiungiRecensione(@PathVariable Long filmId, @RequestParam int voto,
			@RequestParam(required = false) String testo, HttpSession session, Model model) {

		// Prendo l'utente dalla sessione, cioè chi ha effettuato il login
	    Utente utente = (Utente) session.getAttribute("utente");
	    
	    // Se l'utente non è loggato, metto un messaggio e lo rimando alla pagina di login
	    if (utente == null) {
	        model.addAttribute("utenteNoLog", "Devi prima effettuare il login");
	        return "redirect:/login";
	    }

	    // Cerco il film con l'ID passato come parametro
	    Film film = filmRepo.findById(filmId).orElse(null);
	    // Se il film non esiste, rimando alla homepage (o altra pagina)
	    if (film == null) {
	        return "redirect:/";
	    }

	    // Controllo se l'utente ha già scritto una recensione per questo film
	    RecensioneFilm recensioneEsistente = recensioneRepo.findByUtenteAndFilm(utente, film);
	    // Se esiste già una recensione, lo rimando alla pagina per modificarla
	    if (recensioneEsistente != null) {
	        return "redirect:/recensioni/edit/" + recensioneEsistente.getId();
	    }

	    // Creo una nuova recensione
	    RecensioneFilm recensione = new RecensioneFilm();
	    recensione.setFilm(film);         // associo il film alla recensione
	    recensione.setUtente(utente);     // associo l'utente che scrive la recensione
	    recensione.setVoto(voto);         // imposto il voto (obbligatorio)
	    recensione.setCommento(testo);    // imposto il commento (può essere null)

	    // Salvo la recensione nel database
	    recensioneRepo.save(recensione);

	    // Dopo aver salvato la recensione, faccio un redirect alla pagina di dettaglio del film
	    return "redirect:/info/film/" + filmId;
	}

	@GetMapping("/edit/{recensioneId}")
	public String mostraFormModifica(@PathVariable Long recensioneId, HttpSession session, Model model) {

		// Prendo l'utente dalla sessione (chi è loggato)
	    Utente utente = (Utente) session.getAttribute("utente");
	    // Se non è loggato, lo rimando al login
	    if (utente == null) {
	        return "redirect:/login";
	    }

	    // Cerco la recensione da modificare usando l'ID passato nell'URL
	    RecensioneFilm recensione = recensioneRepo.findById(recensioneId).orElse(null);
	    // Se la recensione non esiste, lo rimando alla homepage (o altra pagina)
	    if (recensione == null) {
	        return "redirect:/";
	    }

	    // Controllo che l'utente che ha scritto la recensione sia lo stesso che sta provando a modificarla
	    // Se non coincidono, lo rimando alla pagina di dettaglio del film
	    if (!recensione.getUtente().getId().equals(utente.getId())) {
	        return "redirect:/info/film/" + recensione.getFilm().getId();
	    }

	    // Aggiungo la recensione al Model per poterla mostrare nella view (form di modifica)
	    model.addAttribute("recensione", recensione);
	    // Aggiungo anche il film relativo alla recensione per mostrarne i dati nella pagina
	    model.addAttribute("film", recensione.getFilm());

	    // Ritorno il nome della view (pagina HTML) per modificare la recensione
	    return "recensione-edit";
	}
	
	

	@PutMapping("/edit/{recensioneId}")
	public String modificaRecensione(@PathVariable Long recensioneId, @RequestParam int voto,
			@RequestParam(required = false) String testo, HttpSession session) {

		 // Prendo l'utente loggato dalla sessione
	    Utente utente = (Utente) session.getAttribute("utente");
	    // Se non è loggato, lo rimando al login
	    if (utente == null) {
	        return "redirect:/login";
	    }

	    // Cerco la recensione da modificare tramite l'ID passato come path variable
	    RecensioneFilm recensione = recensioneRepo.findById(recensioneId).orElse(null);
	    // Se la recensione non esiste, torno alla homepage (o altra pagina)
	    if (recensione == null) {
	        return "redirect:/";
	    }

	    // Verifico che chi sta modificando la recensione sia l'utente che l'ha creata
	    if (recensione.getUtente().getId().equals(utente.getId())) {
	        // Se è lo stesso utente, aggiorno il voto e il commento con i nuovi valori passati nella richiesta
	        recensione.setVoto(voto);
	        recensione.setCommento(testo);
	        // Salvo la recensione aggiornata nel database
	        recensioneRepo.save(recensione);
	    }

	    // Alla fine, reindirizzo alla pagina di dettaglio del film a cui appartiene la recensione
	    return "redirect:/info/film/" + recensione.getFilm().getId();
	}
}