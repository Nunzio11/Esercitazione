package com.generationitaly.progettofilm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.generationitaly.progettofilm.entity.Attore;
import com.generationitaly.progettofilm.entity.Film;
import com.generationitaly.progettofilm.entity.Genere;
import com.generationitaly.progettofilm.entity.RecensioneFilm;
import com.generationitaly.progettofilm.entity.Regista;
import com.generationitaly.progettofilm.entity.Utente;
import com.generationitaly.progettofilm.repository.AttoreRepository;
import com.generationitaly.progettofilm.repository.FilmRepository;
import com.generationitaly.progettofilm.repository.GenereRepository;
import com.generationitaly.progettofilm.repository.RecensioneFilmRepository;
import com.generationitaly.progettofilm.repository.RegistaRepository;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping(path = "/")
public class FilmController {

	@Autowired
	private FilmRepository filmRepository;
	@Autowired
	private GenereRepository genereRepository;
	@Autowired
	private AttoreRepository attoreRepository;
	@Autowired
	private RegistaRepository registaRepository;
	@Autowired
	private RecensioneFilmRepository recensioneFilmRepository;

	// Mappa una richiesta GET all'URL radice ("/")
	// Quando un utente visita il sito, questo metodo viene eseguito
	@GetMapping
	public String showListFilm(Model model) {

		// Recupera la lista di tutti i film, ordinati per anno in ordine decrescente
		// (dal più recente al più vecchio)
		List<Film> films = filmRepository.filmOrderByAnnoDesc();

		// Recupera la lista di tutti i generi presenti nel database
		List<Genere> generi = genereRepository.findAll();

		// Aggiunge la lista dei generi al model, con il nome "generi"
		// Sarà accessibile nella pagina HTML
		model.addAttribute("generi", generi);

		// Aggiunge la lista dei film al model, con il nome "listaFilm"
		model.addAttribute("listaFilm", films);

		// Ritorna il nome della pagina HTML da visualizzare (es.
		// templates/index-Buona.html)
		return "index-Buona";
	}

	@GetMapping(path = "/listafilm/Az")
	public String showListFilmAz(
			// Prende i parametri dalla query string (es. genereId=1&genereId=2)
			// Il parametro è opzionale (required = false), quindi può anche non essere
			// presente
			@RequestParam(value = "genereId", required = false) List<Long> generiId, Model model) {

		// Crea una lista di film da mostrare
		List<Film> films;

		// Se non ci sono generi selezionati (parametro nullo o vuoto)
		if (generiId == null || generiId.isEmpty()) {
			// Recupera tutti i film ordinati per titolo in ordine alfabetico (A → Z)
			films = filmRepository.filmOrderByTitoloAsc();
		} else {
			// Recupera i film che appartengono solo ai generi selezionati,
			// ordinati per titolo in ordine alfabetico
			films = filmRepository.filmOrderByTitoloAscPerGenere(generiId);
		}

		// Recupera tutti i generi dal database (per mostrarli nei filtri, ad esempio)
		List<Genere> generi = genereRepository.findAll();

		// Aggiunge la lista dei generi al model per mostrarli nella vista
		model.addAttribute("generi", generi);

		// Aggiunge la lista dei film (filtrati o non filtrati) al model
		model.addAttribute("listaFilm", films);

		// Aggiunge anche i generi selezionati al model (per tenere i checkbox
		// selezionati)
		model.addAttribute("selectedGeneri", generiId);

		// Ritorna il nome della pagina HTML da visualizzare (es. "index-Buona.html")
		return "index-Buona";
	}

	@GetMapping(path = "/listafilm/Za")
	public String showListFilmZa(@RequestParam(value = "genereId", required = false) List<Long> generiId, Model model) {
		List<Film> films;

		// Se l'utente non ha selezionato nessun genere (filtro vuoto o nullo)
		if (generiId == null || generiId.isEmpty()) {
			// Recupera tutti i film ordinati per titolo in ordine Z → A (decrescente)
			films = filmRepository.filmOrderByTitoloDesc();
		} else {
			// Se sono stati selezionati dei generi, recupera solo i film
			// che appartengono a quei generi, ordinati Z → A
			films = filmRepository.filmOrderByTitoloDescPerGenere(generiId);
		}

		// Recupera tutti i generi disponibili dal database
		List<Genere> generi = genereRepository.findAll();

		// Aggiunge la lista dei generi al model per popolare i filtri nella pagina HTML
		model.addAttribute("generi", generi);

		// Aggiunge la lista dei film (filtrati o meno) da mostrare nella pagina
		model.addAttribute("listaFilm", films);

		// Aggiunge al model anche i generi selezionati, così da mantenere
		// i checkbox spuntati nella pagina dopo il filtro
		model.addAttribute("selectedGeneri", generiId);

		// Ritorna il nome della vista HTML da mostrare (index-Buona.html)
		return "index-Buona";
	}

	@GetMapping(path = "/listafilm/AnnoASC")
	public String showListFilmAnnoAsc(@RequestParam(value = "genereId", required = false) List<Long> generiId,
			Model model) {
		List<Film> films;

		// Se l'utente NON ha selezionato alcun genere come filtro
		if (generiId == null || generiId.isEmpty()) {
			// Recupera TUTTI i film ordinati per ANNO in ordine CRESCENTE (dal più vecchio
			// al più recente)
			films = filmRepository.filmOrderByAnnoAsc();
		} else {
			// Se sono stati selezionati dei generi, recupera SOLO i film di quei generi
			// ordinati per ANNO in ordine CRESCENTE
			films = filmRepository.filmOrderByAnnoAscPerGenere(generiId);
		}

		// Recupera tutti i generi dal database (per visualizzare i filtri nella pagina
		// HTML)
		List<Genere> generi = genereRepository.findAll();

		// Aggiunge la lista dei generi al model per renderli disponibili nella vista
		// HTML
		model.addAttribute("generi", generi);

		// Aggiunge la lista dei film da mostrare nella pagina
		model.addAttribute("listaFilm", films);

		// Aggiunge al model anche i generi selezionati (per mantenere i checkbox
		// spuntati)
		model.addAttribute("selectedGeneri", generiId);

		// Ritorna la pagina HTML da visualizzare (index-Buona.html)
		return "index-Buona";
	}

	@GetMapping(path = "/listafilm/AnnoDESC")
	public String showListFilmAnnoDesc(@RequestParam(value = "genereId", required = false) List<Long> generiId,
			Model model) {
		List<Film> films;

		// Se non sono stati selezionati generi (nessun filtro attivo)
		if (generiId == null || generiId.isEmpty()) {
			// Recupera TUTTI i film ordinati per anno in modo DECRESCENTE (dal più recente
			// al più vecchio)
			films = filmRepository.filmOrderByAnnoDesc();
		} else {
			// Se sono stati selezionati dei generi, recupera SOLO i film di quei generi,
			// ordinati per anno decrescente
			films = filmRepository.filmOrderByAnnoDescPerGenere(generiId);
		}

		// Recupera tutti i generi dal database per visualizzare i filtri nella pagina
		List<Genere> generi = genereRepository.findAll();

		// Aggiunge i generi al model per renderli accessibili nella pagina HTML
		model.addAttribute("generi", generi);

		// Aggiunge la lista dei film ottenuta (filtrata o meno) al model
		model.addAttribute("listaFilm", films);

		// Aggiunge i generi selezionati (se presenti) al model,
		// utile per mantenere i checkbox selezionati dopo il filtro
		model.addAttribute("selectedGeneri", generiId);

		// Restituisce il nome della vista (pagina HTML) da visualizzare
		return "index-Buona";
	}

	// Questo metodo gestisce una richiesta GET all'URL "/info/film/{filmID}"
	// Ad esempio: /info/film/5 → Mostra i dettagli del film con ID 5
	@GetMapping(path = "/info/film/{filmID}")
	public String showFilmDettaglio(@PathVariable("filmID") Long id, // Estrae l'ID del film dalla URL
			Model model, // Oggetto per passare dati alla vista HTML
			HttpSession session // Serve per ottenere l'utente loggato (se esiste)
	) {
		// Recupera il film dal database tramite l'ID (se non esiste, ritorna null)
		Film film = filmRepository.findById(id).orElse(null);

		// Recupera la lista di recensioni associate a quel film
		List<RecensioneFilm> recensioni = recensioneFilmRepository.findByFilm(film);

		// Calcola la media dei voti dati a questo film (può essere null se non ci sono
		// recensioni)
		Double mediaVoto = recensioneFilmRepository.calcolaMediaVotoPerfilm(id);

		// Conta quante recensioni sono state fatte per questo film
		long numeroDiRecensioni = recensioneFilmRepository.countByFilmId(id);

		// Recupera il regista del film tramite l'ID del film
		Regista regista = registaRepository.findByFilmId(id);

		// Ottiene l'utente loggato dalla sessione (null se non loggato)
		Utente utente = (Utente) session.getAttribute("utente");

		// Aggiunge il regista al model (da mostrare nella vista)
		model.addAttribute("registaFilm", regista);

		// Aggiunge il film al model
		model.addAttribute("film", film);

		// Aggiunge la lista delle recensioni
		model.addAttribute("recensioni", recensioni);

		// Aggiunge il numero di recensioni
		model.addAttribute("countRecensioni", numeroDiRecensioni);

		// Aggiunge la media voto (null o un numero da 1 a 5, ad esempio)
		model.addAttribute("mediaVoto", mediaVoto);

		// Variabile per sapere se l'utente ha già recensito questo film
		boolean haGiaRecensito = false;

		// Se l'utente è loggato...
		if (utente != null) {
			// ...cerca se ha già fatto una recensione per questo film
			RecensioneFilm recensioneEsistente = recensioneFilmRepository.findByUtenteAndFilm(utente, film);

			// Se la recensione esiste, l'utente ha già recensito
			haGiaRecensito = (recensioneEsistente != null);
		}

		// Passa al model l'informazione se l'utente ha già recensito
		model.addAttribute("haGiaRecensito", haGiaRecensito);

		// Ritorna il nome della pagina HTML da mostrare (es.
		// templates/filmDettaglio.html)
		return "filmDettaglio";
	}

	@GetMapping(path = "/filtro/genere/{genereId}")
	public String filtroFilmPerGenereSingolo(@PathVariable Long genereId, Model model) {

		// Recupera la lista di film che appartengono al genere selezionato
		List<Film> filmsGeneri = filmRepository.findFilmByGenere(genereId);

		// Recupera la lista completa di tutti i generi (serve per i filtri nella
		// pagina)
		List<Genere> generi = genereRepository.findAll();

		// Aggiunge al model la lista dei generi per mostrarli nella pagina
		model.addAttribute("generi", generi);

		// Aggiunge al model la lista dei film filtrati per il genere selezionato
		model.addAttribute("listaFilm", filmsGeneri);

		// Aggiunge l'ID del genere selezionato al model, come lista (anche se singolo),
		// così da poterlo gestire facilmente come lista nella vista (checkbox,
		// selezioni, ecc.)
		model.addAttribute("selectedGeneri", List.of(genereId));

		// Ritorna il nome della vista da visualizzare (index-Buona.html)
		return "index-Buona";
	}

	@GetMapping(path = "/filtroFilm/genere")
	public String filtroFilmPerGeneri(@RequestParam(value = "genereId", required = false) List<Long> generiId,
			Model model) {
		// Recupera la lista di film che appartengono ad almeno uno dei generi
		// selezionati
		List<Film> filmsGeneri = filmRepository.findFilmByGeneri(generiId);

		// Recupera tutti i generi disponibili (per visualizzarli nella vista come
		// filtri)
		List<Genere> generi = genereRepository.findAll();

		// Aggiunge la lista di tutti i generi al model
		model.addAttribute("generi", generi);

		// Aggiunge al model i film filtrati per i generi selezionati
		model.addAttribute("listaFilm", filmsGeneri);

		// Aggiunge al model i generi selezionati per mantenere i checkbox spuntati
		model.addAttribute("selectedGeneri", generiId);

		// Ritorna la pagina HTML da visualizzare
		return "index-Buona";
	}

	// Questo metodo gestisce la ricerca avanzata tramite GET all'URL
	// "/film/ricercaPer"
	// Supporta ricerca per testo, per generi, e con vari filtri di ordinamento
	@GetMapping(path = "/film/ricercaPer")
	public String showRisultatiRicerca(
			// Parametro opzionale: stringa da cercare (titolo film, nome attore, regista,
			// ecc.)
			@RequestParam(value = "elementoRicerca", required = false) String ricerca,

			// Parametro opzionale: lista di ID di generi selezionati
			@RequestParam(value = "genereId", required = false) List<Long> generiId,

			// Parametro opzionale per definire l’ordinamento da applicare (az, za, annoAsc,
			// annoDesc)
			@RequestParam(value = "filtroApplicato", defaultValue = "") String filtro,

			// Oggetto per passare dati alla vista HTML
			Model model) {
		// Liste che conterranno i risultati della ricerca
		List<Film> films;
		List<Attore> attori;
		List<Regista> registi;

		// Verifica se l'utente ha inserito una stringa di ricerca
		boolean ricercaPerStringa = ricerca != null && !ricerca.isBlank();

		// Verifica se l'utente ha selezionato uno o più generi
		boolean ricercaPerGeneri = generiId != null && !generiId.isEmpty();

		// CASO 1: ricerca sia per stringa che per generi
		if (ricercaPerStringa && ricercaPerGeneri) {
			switch (filtro) {
			case "az":
				films = filmRepository.findFilmByStringAndGeneriOrderByTitoloAsc(ricerca, generiId);
				attori = attoreRepository.findAttoreByStringOrderByNomeAsc(ricerca);
				registi = registaRepository.findRegistaByStringOrderByNomeAsc(ricerca);
				break;
			case "za":
				films = filmRepository.findFilmByStringAndGeneriOrderByTitoloDesc(ricerca, generiId);
				attori = attoreRepository.findAttoreByStringOrderByNomeDesc(ricerca);
				registi = registaRepository.findRegistaByStringOrderByNomeDesc(ricerca);
				break;
			case "annoAsc":
				films = filmRepository.findFilmByStringAndGeneriOrderByAnnoAsc(ricerca, generiId);
				attori = attoreRepository.findAttoreByStringOrderByNomeAsc(ricerca);
				registi = registaRepository.findRegistaByStringOrderByNomeAsc(ricerca);
				break;
			case "annoDesc":
				films = filmRepository.findFilmByStringAndGeneriOrderByAnnoDesc(ricerca, generiId);
				attori = attoreRepository.findAttoreByStringOrderByNomeDesc(ricerca);
				registi = registaRepository.findRegistaByStringOrderByNomeDesc(ricerca);
				break;
			default:
				// Se nessun filtro è specificato, si usano le versioni "base"
				films = filmRepository.findFilmByStringAndGeneri(ricerca, generiId);
				attori = attoreRepository.findAttoreByString(ricerca);
				registi = registaRepository.findRegistaByString(ricerca);
			}
		}

		// CASO 2: ricerca solo per stringa
		else if (ricercaPerStringa) {
			switch (filtro) {
			case "az":
				films = filmRepository.findFilmByStringOrderByTitoloAsc(ricerca);
				attori = attoreRepository.findAttoreByStringOrderByNomeAsc(ricerca);
				registi = registaRepository.findRegistaByStringOrderByNomeAsc(ricerca);
				break;
			case "za":
				films = filmRepository.findFilmByStringOrderByTitoloDesc(ricerca);
				attori = attoreRepository.findAttoreByStringOrderByNomeDesc(ricerca);
				registi = registaRepository.findRegistaByStringOrderByNomeDesc(ricerca);
				break;
			case "annoAsc":
				films = filmRepository.findFilmByStringOrderByAnnoAsc(ricerca);
				attori = attoreRepository.findAttoreByStringOrderByNomeAsc(ricerca);
				registi = registaRepository.findRegistaByStringOrderByNomeDesc(ricerca); // Attenzione: uno è Asc,
																							// l’altro Desc
				break;
			case "annoDesc":
				films = filmRepository.findFilmByStringOrderByAnnoDesc(ricerca);
				attori = attoreRepository.findAttoreByStringOrderByNomeDesc(ricerca);
				registi = registaRepository.findRegistaByStringOrderByNomeDesc(ricerca);
				break;
			default:
				films = filmRepository.findFilmByString(ricerca);
				attori = attoreRepository.findAttoreByString(ricerca);
				registi = registaRepository.findRegistaByString(ricerca);
			}
		}

		// CASO 3: ricerca solo per generi
		else if (ricercaPerGeneri) {
			switch (filtro) {
			case "az":
				films = filmRepository.findFilmByGeneriOrderByTitoloAsc(generiId);
				break;
			case "za":
				films = filmRepository.findFilmByGeneriOrderByTitoloDesc(generiId);
				break;
			case "annoAsc":
				films = filmRepository.findFilmByGeneriOrderByAnnoAsc(generiId);
				break;
			case "annoDesc":
				films = filmRepository.findFilmByGeneriOrderByAnnoDesc(generiId);
				break;
			default:
				films = filmRepository.findFilmByGeneri(generiId);
			}
			// In questo caso non c'è ricerca testuale, quindi si mostrano tutti
			// attori/registi
			attori = attoreRepository.findAll();
			registi = registaRepository.findAll();
		}

		// CASO 4: nessuna ricerca, né per stringa né per generi → ricerca vuota
		else {
			// Messaggio da mostrare in pagina se non ci sono input di ricerca
			model.addAttribute("ricercaVuota", "Non ci sono risultati da mostrare");

			// Mostra tutto per non lasciare la pagina vuota
			films = filmRepository.findAll();
			attori = attoreRepository.findAll();
			registi = registaRepository.findAll();
		}

		// Aggiunge al model tutto ciò che serve per la pagina "risultati-ricerca"
		model.addAttribute("generi", genereRepository.findAll());
		model.addAttribute("listaFilm", films);
		model.addAttribute("listaRegisti", registi);
		model.addAttribute("listaAttori", attori);
		model.addAttribute("selectedGeneri", generiId);
		model.addAttribute("elementoRicerca", ricerca);

		// Ritorna la pagina HTML con i risultati
		return "risultati-ricerca";
	}

	// Mappatura GET per la URL "/filtroRicerca/Az"
	// Questo metodo mostra la lista di film ordinata in modo alfabetico crescente
	// (A-Z)
	// Può filtrare per generi selezionati e accetta un parametro di ricerca
	// testuale (anche se non usato nel filtro qui)
	@GetMapping(path = "/filtroRicerca/Az")
	public String showRicercaFilmAz(
			// Lista opzionale di ID dei generi per filtrare i film
			@RequestParam(value = "genereId", required = false) List<Long> generiId,

			// Stringa opzionale per la ricerca testuale (titolo, attore, ecc.) — qui non
			// usata per filtrare direttamente i film
			@RequestParam(value = "elementoRicerca", required = false) String ricerca,

			// Model per passare dati alla vista HTML
			Model model) {
		List<Film> films;

		// Se non sono stati selezionati generi, recupera tutti i film ordinati per
		// titolo in modo crescente (A-Z)
		if (generiId == null || generiId.isEmpty()) {
			films = filmRepository.filmOrderByTitoloAsc();
		}
		// Se sono stati selezionati generi, recupera i film appartenenti a quei generi
		// e ordina per titolo (A-Z)
		else {
			films = filmRepository.findFilmByGeneriOrderByTitoloAsc(generiId);
		}

		// Recupera tutti i generi dal database (per mostrare la lista dei filtri
		// disponibili nella vista)
		List<Genere> generi = genereRepository.findAll();

		// Aggiunge i generi disponibili al model (per la vista)
		model.addAttribute("generi", generi);

		// Aggiunge la lista di film filtrata e ordinata al model
		model.addAttribute("listaFilm", films);

		// Aggiunge i generi selezionati (eventuali) al model per mantenere la selezione
		// nei filtri nella vista
		model.addAttribute("selectedGeneri", generiId);

		// Aggiunge il testo di ricerca inserito dall'utente, così può essere mostrato
		// nella pagina o mantenuto nel form
		model.addAttribute("elementoRicerca", ricerca);

		// Ritorna la pagina HTML "risultati-ricerca" che mostrerà i risultati della
		// ricerca/filtri
		return "risultati-ricerca";
	}

	// Mappatura GET per la URL "/filtroRicerca/Za"
	// Questo metodo mostra la lista di film ordinata in modo alfabetico decrescente
	// (Z-A)
	// Può filtrare per generi selezionati e riceve anche un parametro di ricerca
	// testuale (anche se non usato nel filtro)
	@GetMapping(path = "/filtroRicerca/Za")
	public String showRicercaFilmZa(
			// Lista opzionale di ID dei generi per filtrare i film
			@RequestParam(value = "genereId", required = false) List<Long> generiId,

			// Stringa opzionale per la ricerca testuale (non usata direttamente nel filtro
			// qui)
			@RequestParam(value = "elementoRicerca", required = false) String ricerca,

			// Model per passare dati alla vista HTML
			Model model) {
		List<Film> films;

		// Se non ci sono generi selezionati, recupera tutti i film ordinati per titolo
		// in modo decrescente (Z-A)
		if (generiId == null || generiId.isEmpty()) {
			films = filmRepository.filmOrderByTitoloDesc();
		}
		// Se invece ci sono generi selezionati, recupera i film di quei generi ordinati
		// per titolo in modo decrescente (Z-A)
		else {
			films = filmRepository.findFilmByGeneriOrderByTitoloDesc(generiId);
		}

		// Recupera tutti i generi dal database per mostrare i filtri disponibili nella
		// vista
		List<Genere> generi = genereRepository.findAll();

		// Aggiunge la lista dei generi al model
		model.addAttribute("generi", generi);

		// Aggiunge la lista di film filtrata e ordinata al model
		model.addAttribute("listaFilm", films);

		// Aggiunge i generi selezionati per mantenere la selezione nei filtri in pagina
		model.addAttribute("selectedGeneri", generiId);

		// Aggiunge la stringa di ricerca per poterla mostrare o mantenere nella vista
		// (anche se non usata per filtrare)
		model.addAttribute("elementoRicerca", ricerca);

		// Ritorna la pagina HTML "risultati-ricerca" per mostrare i risultati filtrati
		return "risultati-ricerca";
	}

	// Mappatura GET per la URL "/filtroRicerca/AnnoASC"
	// Metodo che mostra la lista di film ordinata per anno di uscita in modo
	// crescente (dal più vecchio al più nuovo)
	// Accetta filtri opzionali per i generi e un testo di ricerca (anche se qui il
	// testo non viene usato come filtro)
	@GetMapping(path = "/filtroRicerca/AnnoASC")
	public String showRicercaAnnoAsc(
			// Lista opzionale di ID dei generi per filtrare i film
			@RequestParam(value = "genereId", required = false) List<Long> generiId,

			// Stringa opzionale di ricerca testuale (titolo, ecc.), che però non filtra
			// realmente in questo metodo
			@RequestParam(value = "elementoRicerca", required = false) String ricerca,

			// Model per passare dati alla vista HTML
			Model model) {
		List<Film> films;

		// Se non sono stati selezionati generi, prende tutti i film ordinati per anno
		// in modo crescente
		if (generiId == null || generiId.isEmpty()) {
			films = filmRepository.filmOrderByAnnoAsc();
		}
		// Se ci sono generi selezionati, prende solo i film di quei generi, sempre
		// ordinati per anno crescente
		else {
			films = filmRepository.findFilmByGeneriOrderByAnnoAsc(generiId);
		}

		// Recupera la lista completa di generi per mostrare i filtri disponibili nella
		// pagina
		List<Genere> generi = genereRepository.findAll();

		// Aggiunge la lista dei generi al model per la vista
		model.addAttribute("generi", generi);

		// Aggiunge la lista dei film filtrati e ordinati al model
		model.addAttribute("listaFilm", films);

		// Aggiunge i generi selezionati al model per mantenere la selezione dei filtri
		// nella pagina
		model.addAttribute("selectedGeneri", generiId);

		// Aggiunge il testo di ricerca per poterlo mostrare o mantenere nella pagina
		// (anche se non usato per filtrare)
		model.addAttribute("elementoRicerca", ricerca);

		// Restituisce la vista "risultati-ricerca" che mostrerà i risultati della
		// ricerca e filtri
		return "risultati-ricerca";
	}

	// Mappatura GET per la URL "/filtroRicerca/AnnoDESC"
	// Metodo che mostra la lista di film ordinata per anno di uscita in modo
	// decrescente (dal più nuovo al più vecchio)
	// Può filtrare per generi selezionati e riceve anche una stringa di ricerca
	// (che però qui non viene usata come filtro)
	@GetMapping(path = "/filtroRicerca/AnnoDESC")
	public String showRicercaAnnoDesc(
			// Lista opzionale di ID dei generi da usare come filtro
			@RequestParam(value = "genereId", required = false) List<Long> generiId,

			// Parametro opzionale con testo di ricerca (non usato qui per filtrare, ma
			// passato alla vista)
			@RequestParam(value = "elementoRicerca", required = false) String ricerca,

			// Model per passare dati alla vista HTML
			Model model) {
		List<Film> films;

		// Se non ci sono generi selezionati, prendo tutti i film ordinati per anno in
		// modo decrescente
		if (generiId == null || generiId.isEmpty()) {
			films = filmRepository.filmOrderByAnnoDesc();
		}
		// Altrimenti prendo solo i film appartenenti ai generi specificati, sempre
		// ordinati per anno decrescente
		else {
			films = filmRepository.findFilmByGeneriOrderByAnnoDesc(generiId);
		}

		// Recupero la lista completa dei generi per popolare i filtri nella pagina
		List<Genere> generi = genereRepository.findAll();

		// Aggiungo la lista dei generi al model per la vista
		model.addAttribute("generi", generi);

		// Aggiungo la lista dei film filtrati e ordinati al model
		model.addAttribute("listaFilm", films);

		// Aggiungo i generi selezionati al model per mantenere la selezione dei filtri
		model.addAttribute("selectedGeneri", generiId);

		// Aggiungo il testo di ricerca per mantenerlo visibile nella pagina (anche se
		// non usato per filtrare)
		model.addAttribute("elementoRicerca", ricerca);

		// Ritorno la vista "risultati-ricerca" per mostrare i film filtrati e ordinati
		return "risultati-ricerca";
	}
}