package com.generationitaly.progettofilm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.generationitaly.progettofilm.entity.Film;
import com.generationitaly.progettofilm.entity.RecensioneFilm;
import com.generationitaly.progettofilm.entity.Utente;

public interface RecensioneFilmRepository extends JpaRepository<RecensioneFilm, Long> {
	
	// Conta quante recensioni ha un film dato l'id del film
    long countByFilmId(Long filmId);

    // Trova tutte le recensioni associate a un determinato film
    List<RecensioneFilm> findByFilm(Film film);

    // Trova le recensioni fatte da un utente specifico su un film specifico
    List<RecensioneFilm> findByFilmAndUtente(Film film, Utente utente);

    // Calcola la media dei voti per un film dato l'id (query JPQL personalizzata)
    @Query("SELECT AVG(r.voto) FROM RecensioneFilm r WHERE r.film.id =?1")
    Double calcolaMediaVotoPerfilm(Long filmId);

    // Recupera la lista degli utenti che hanno recensito un determinato film
    @Query("SELECT r.utente FROM RecensioneFilm r WHERE r.film.id=?1")
    List<Utente> findUtenteRecensore(Long filmId);

    // Trova tutte le recensioni fatte da un utente dato il suo id
    List<RecensioneFilm> findByUtenteId(Long id);

    // Trova la recensione fatta da un utente specifico per un film specifico (se esiste)
    RecensioneFilm findByUtenteAndFilm(Utente utente, Film film);
	

}
