package com.generationitaly.progettofilm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.generationitaly.progettofilm.entity.Genere;

public interface GenereRepository extends JpaRepository<Genere, Long>{

}
