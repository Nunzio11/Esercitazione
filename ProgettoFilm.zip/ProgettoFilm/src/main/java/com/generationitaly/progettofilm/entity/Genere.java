package com.generationitaly.progettofilm.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

/*
CREATE TABLE genere (
	    id BIGINT NOT NULL AUTO_INCREMENT,
	    nome VARCHAR(45) NOT NULL UNIQUE,
	    PRIMARY KEY (id)
	);
*/

@Entity // Definisce questa classe come entità JPA, mappata su una tabella nel DB
@Table(name = "genere") // Specifica il nome della tabella nel database
public class Genere {

    @Id // Campo chiave primaria della tabella
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Valore auto-incrementato dal DB
    @Column(name = "id") // Colonna "id" nella tabella
    private long id;

    @Column(name = "nome", nullable = false, length = 45) 
    // Colonna "nome", obbligatoria, con lunghezza massima 45 caratteri
    private String nome;

    @OneToMany(
        mappedBy = "genere", // Indica che la relazione è mappata dal campo "genere" nella classe FilmGenere
        fetch = FetchType.EAGER, // Caricamento immediato della lista associata quando si carica un Genere
        cascade = CascadeType.ALL // Tutte le operazioni (persist, remove, etc.) si propagano a filmGenere
    )
    private List<FilmGenere> filmGenere; // Lista dei film associati a questo genere tramite FilmGenere (relazione molti-a-molti)


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@Override
	public String toString() {
		return "Genere [id=" + id + ", nome=" + nome + "]";
	}
	
	
	
}
