package com.generationitaly.progettofilm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.generationitaly.progettofilm.entity.RecensioneFilm;
import com.generationitaly.progettofilm.entity.Utente;
import com.generationitaly.progettofilm.repository.RecensioneFilmRepository;
import com.generationitaly.progettofilm.repository.UtenteRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class UtenteController {

	@Autowired
	private UtenteRepository utenteRepository;

	@Autowired
	private RecensioneFilmRepository recensioneFilmRepository;

	@GetMapping(path = "/profilo/{utenteId}")
		public String getPersona(@PathVariable("utenteId") Long id, Model model, HttpSession session) {
		// 🔐 Controllo: se l'utente non è loggato (non presente in sessione), reindirizza alla home
        if (session.getAttribute("utente") == null) {
            return "redirect:/home";
        }

        // 🔎 Recupera l'utente dal database in base all'ID passato nell'URL
        Utente utente = utenteRepository.findById(id).orElse(null);

        // 📄 Recupera tutte le recensioni scritte da quell'utente
        List<RecensioneFilm> recensioniDiUtente = recensioneFilmRepository.findByUtenteId(id);

        // 📦 Aggiunge le recensioni al model per poterle usare nella view
        model.addAttribute("recensioniUtente", recensioniDiUtente);

        // 👤 Aggiunge anche l'utente al model (così da mostrare i suoi dati nel profilo)
        model.addAttribute("utente", utente);

        // 👁️‍🗨️ Restituisce la view chiamata "profilo-utente" (es. profilo-utente.html)
        return "profilo-utente";
    }

}
