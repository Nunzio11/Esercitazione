package com.generationitaly.progettofilm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.generationitaly.progettofilm.entity.Film;

public interface FilmRepository extends JpaRepository<Film, Long>{

	

	
	//inizio query ordinamento
	@Query("from Film f order by f.titolo asc")
	List<Film> filmOrderByTitoloAsc();
	
	@Query("select f from Film f join f.filmGenere fg where fg.genere.id in (?1) order by f.titolo asc")
	List<Film> filmOrderByTitoloAscPerGenere(List<Long> generiId);
	
	@Query("from Film f order by f.titolo desc")
	List<Film> filmOrderByTitoloDesc();
	
	@Query("select f from Film f join f.filmGenere fg where fg.genere.id in (?1) order by f.titolo desc")
	List<Film> filmOrderByTitoloDescPerGenere(List<Long> generiId);
	
	@Query("from Film f order by f.annoUscita asc")
	List<Film> filmOrderByAnnoAsc();
	
	@Query("select f from Film f join f.filmGenere fg where fg.genere.id in (?1) order by f.annoUscita asc")
	List<Film> filmOrderByAnnoAscPerGenere(List<Long> generiId);
	
	@Query("from Film f order by f.annoUscita desc")
	List<Film> filmOrderByAnnoDesc();
	
	@Query("select f from Film f join f.filmGenere fg where fg.genere.id in (?1) order by f.annoUscita desc")
	List<Film> filmOrderByAnnoDescPerGenere(List<Long> generiId);
	//fine query ordinamento
	
	//inzio query ricerca
	@Query("from Film f join f.filmAttore fa where fa.attore.id=?1")
	List<Film> findFilmByAttore(Long id);
	
	@Query("from Film f join filmGenere fg where fg.genere.id in (?1)")
	List<Film> findFilmByGeneri(List<Long> generi);
	
	@Query("from Film f where f.titolo like %?1%")
	List<Film> findFilmByString(String string);
	
	@Query("from Film f where f.titolo like %?1% order by f.titolo asc")
	List<Film> findFilmByStringAndGeneriOrderByTitoloAsc(String ricerca, List<Long> generiId);
	
	@Query("from Film f where f.titolo like %?1% order by f.titolo desc")
	List<Film> findFilmByStringOrderByTitoloDesc(String stringa);

	@Query("from Film f where f.titolo like %?1% order by f.annoUscita asc")
	List<Film> findFilmByStringOrderByAnnoAsc(String stringa);

	@Query("from Film f where f.titolo like %?1% order by f.annoUscita desc")
	List<Film> findFilmByStringOrderByAnnoDesc(String stringa);

	@Query("from Film f join f.filmGenere fg where fg.genere.id=?1")
	List<Film> findFilmByGenere(Long id);
	
	@Query("from Film f join f.filmGenere fg where fg.genere.id in (?2) and f.titolo like %?1%")
	List<Film> findFilmByStringAndGeneri(String ricerca, List<Long> listaGenId);

	@Query("from Film f join f.filmGenere fg where fg.genere.id in (?2) and f.titolo like %?1% order by f.titolo desc")
	List<Film> findFilmByStringAndGeneriOrderByTitoloDesc(String stringa, List<Long> listaIdGen);

	@Query("from Film f join f.filmGenere fg where fg.genere.id in (?2) and f.titolo like %?1% order by f.annoUscita asc")
	List<Film> findFilmByStringAndGeneriOrderByAnnoAsc(String stringa, List<Long> listaIdGen);

	@Query("from Film f join f.filmGenere fg where fg.genere.id in (?2) and f.titolo like %?1% order by f.annoUscita desc")
	List<Film> findFilmByStringAndGeneriOrderByAnnoDesc(String stringa, List<Long> listaIdGen);

	@Query("from Film f join f.filmGenere fg where fg.genere.id in (?1) order by f.titolo asc")
	List<Film> findFilmByGeneriOrderByTitoloAsc(List<Long> listaIdGen);

	@Query("from Film f join f.filmGenere fg where fg.genere.id in (?1) order by f.titolo desc")
	List<Film> findFilmByGeneriOrderByTitoloDesc(List<Long> listaIdGen);

	@Query("from Film f join f.filmGenere fg where fg.genere.id in (?1) order by f.annoUscita asc")
	List<Film> findFilmByGeneriOrderByAnnoAsc(List<Long> listaIdGen);

	@Query("from Film f join f.filmGenere fg where fg.genere.id in (?1) order by f.annoUscita desc")
	List<Film> findFilmByGeneriOrderByAnnoDesc(List<Long> listaIdGen);

	@Query("from Film f where f.titolo like %?1%order by f.titolo asc")
	List<Film> findFilmByStringOrderByTitoloAsc(String ricerca);




	
}
