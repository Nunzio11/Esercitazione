package com.generationitaly.progettofilm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class LogoutController {

	@PostMapping(path = "/logout")                // Mappa la richiesta POST su /logout
	public String logout(HttpSession session) {   // Metodo che riceve la sessione HTTP

	    session.invalidate();                     // Invalida la sessione: elimina tutti gli attributi e "disconnette" l'utente

	    return "redirect:/";                      // Reindirizza alla home page ("/") dopo il logout

	}

}
