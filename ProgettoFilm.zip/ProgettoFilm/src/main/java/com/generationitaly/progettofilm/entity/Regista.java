package com.generationitaly.progettofilm.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

/*
 CREATE TABLE regista (
    id BIGINT NOT NULL AUTO_INCREMENT,
    foto TEXT,
    nome VARCHAR(45) NOT NULL,
    cognome VARCHAR(45) NOT NULL,
    biografia TEXT,
    PRIMARY KEY (id)
); 
 */
@Entity // Definisce la classe come entità JPA, mappata alla tabella "regista"
@Table(name = "regista") // Specifica il nome della tabella nel database
public class Regista {

    @Id // Definisce il campo "id" come chiave primaria della tabella
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    // Il valore dell'id è generato automaticamente dal database (auto-increment)
    @Column(name = "id")
    private long id;
    
    @Column(name = "foto", nullable = true, length = 6000)
    // Colonna "foto" opzionale, può contenere fino a 6000 caratteri (URL o base64)
    private String foto;
    
    @Column(name = "nome", nullable = false, length = 45)
    // Colonna "nome" obbligatoria, massimo 45 caratteri
    private String nome;
    
    @Column(name = "cognome", nullable = false, length = 45)
    // Colonna "cognome" obbligatoria, massimo 45 caratteri
    private String cognome;
    
    @Column(name = "biografia", nullable = true, length = 10000)
    // Colonna "biografia" opzionale, può contenere fino a 10.000 caratteri (descrizione testo libero)
    private String biografia;
    
    @OneToMany(mappedBy = "regista", fetch = FetchType.EAGER)
    // Relazione uno a molti: un regista può dirigere molti film
    // "mappedBy" indica che la proprietà "regista" è definita nella classe Film
    // FetchType.EAGER carica i film associati subito insieme al regista
    private List<Film> films;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getBiografia() {
		return biografia;
	}

	public void setBiografia(String biografia) {
		this.biografia = biografia;
	}
	
	public List<Film> getFilms() {
		return films;
	}

	public void setFilms(List<Film> films) {
		this.films = films;
	}

	@Override
	public String toString() {
		return "Regista [id=" + id + ", foto=" + foto + ", nome=" + nome + ", cognome=" + cognome + ", biografia="
				+ biografia + "]";
	}
	
	
	
}
