package com.generationitaly.progettofilm.entity;

import org.hibernate.annotations.Check;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;


@Check(constraints = "voto BETWEEN 1 AND 5") // Vincolo di check SQL che assicura che 'voto' sia compreso tra 1 e 5
@Entity // Definisce la classe come entità JPA, mappata su una tabella del DB
@Table(
    name="recensione_film", 
    uniqueConstraints = @UniqueConstraint(columnNames = {"film_id", "utente_id"})
    // Vincolo unico che impedisce a uno stesso utente di recensire lo stesso film più di una volta
)
public class RecensioneFilm {

    @Id // Chiave primaria della tabella
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Valore auto-incrementato generato dal DB
    @Column(name="id") // Colonna "id" nella tabella
    private Long id;

    @Column(name="commento", length = 10000) 
    // Colonna "commento" che può contenere fino a 10.000 caratteri (testo libero della recensione)
    private String commento;
    
    @Column(name="voto", nullable = false) 
    // Colonna "voto", obbligatoria, con valore intero (da 1 a 5, vincolato da @Check)
    private int voto;
    
    @ManyToOne
    @JoinColumn(name="film_id", nullable=false) 
    // Molti a uno con Film: ogni recensione appartiene a un solo film (FK film_id non nulla)
    private Film film;
    
    @ManyToOne
    @JoinColumn(name="utente_id", nullable=false) 
    // Molti a uno con Utente: ogni recensione appartiene a un solo utente (FK utente_id non nulla)
    private Utente utente;
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCommento() {
		return commento;
	}
	public void setCommento(String commento) {
		this.commento = commento;
	}
	public int getVoto() {
		return voto;
	}
	public void setVoto(int voto) {
		this.voto = voto;
	}
	public Film getFilm() {
		return film;
	}
	public void setFilm(Film film) {
		this.film = film;
	}
	public Utente getUtente() {
		return utente;
	}
	public void setUtente(Utente utente) {
		this.utente = utente;
	}
	@Override
	public String toString() {
		return "RecensioneFilm [id=" + id + ", commento=" + commento + ", voto=" + voto + ", film=" + film + ", utente="
				+ utente + "]";
	}
	
	
	
}
