package com.generationitaly.progettofilm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.generationitaly.progettofilm.entity.Attore;

public interface AttoreRepository extends JpaRepository<Attore, Long> {
    // Estende JpaRepository, quindi eredita i metodi CRUD base (findAll, findById, save, delete, ecc.)

    // 🔍 Cerca attori il cui nome e cognome (o cognome e nome) contengono la stringa passata
    // Esempio: "Robert Downey" o "Downey Robert"
    @Query("from Attore a where concat(a.nome, ' ', a.cognome) like %?1 or concat(a.cognome, ' ', a.nome) like %?1%")
    List<Attore> findAttoreByString(String string);

    // 🔍 Come sopra, ma ordina per nome e cognome in ordine crescente (A-Z)
    @Query("from Attore a where concat(a.nome, ' ', a.cognome) like %?1%  or concat(a.cognome, ' ', a.nome) like %?1% order by a.nome asc, a.cognome asc")
    List<Attore> findAttoreByStringOrderByNomeAsc(String string);

    // 🔍 Come sopra, ma ordina per nome crescente (A-Z) e cognome decrescente (Z-A)
    @Query("from Attore a where concat(a.nome, ' ', a.cognome) like %?1%  or concat(a.cognome, ' ', a.nome) like %?1% order by a.nome asc, a.cognome desc")
    List<Attore> findAttoreByStringOrderByNomeDesc(String string);
}
