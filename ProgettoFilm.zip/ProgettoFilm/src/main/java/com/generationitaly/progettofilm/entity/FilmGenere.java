package com.generationitaly.progettofilm.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity // Indica che questa classe è una entità JPA, cioè rappresenta una tabella nel DB
@Table(
    name = "film_genere", // Nome della tabella nel database
    uniqueConstraints = @UniqueConstraint(columnNames = {"film_id", "genere_id"}) 
    // Impone che ogni combinazione di film e genere sia unica (evita duplicati)
)
public class FilmGenere {

    @Id // Indica il campo ID come chiave primaria
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-incremento del campo ID
    @Column(name = "id") // Mappatura con la colonna "id" nel database
    private long id;

    @ManyToOne // Molti record in FilmGenere possono riferirsi allo stesso Film
    @JoinColumn(name = "film_id", nullable = false) 
    // Crea la colonna "film_id" come chiave esterna, obbligatoria
    private Film film;

    @ManyToOne // Molti record in FilmGenere possono riferirsi allo stesso Genere
    @JoinColumn(name = "genere_id", nullable = false) 
    // Crea la colonna "genere_id" come chiave esterna, obbligatoria
    private Genere genere;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Film getFilm() {
		return film;
	}

	public void setFilm(Film film) {
		this.film = film;
	}

	public Genere getGenere() {
		return genere;
	}

	public void setGenere(Genere genere) {
		this.genere = genere;
	}

	@Override
	public String toString() {
		return "FilmGenere [id=" + id + ", genere=" + genere + "]";
	}

	
	
}
