package com.generationitaly.progettofilm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.generationitaly.progettofilm.dto.RegistDto;
import com.generationitaly.progettofilm.repository.UtenteRepository;

@Controller
public class RegistrazioneController {

	@Autowired
	private UtenteRepository utenteRepository; // Inietta il repository per gestire gli utenti

	@GetMapping(path = "/Register") // Gestisce la richiesta GET su /Register
	public String showRegisterForm(Model model) {
		model.addAttribute("registDto", new RegistDto()); // Aggiunge un nuovo oggetto RegistDto al modello, usato per
															// il form di registrazione
		return "register-utente"; // Ritorna la view (pagina) "register-utente" per mostrare il form di
									// registrazione
	}

	@PostMapping(path = "/Register") // Gestisce la richiesta POST su /Register (invio del form)
	public String submitRegisterForm(@ModelAttribute RegistDto registDto) {
		utenteRepository.save(registDto.toEntity()); // Converte il DTO in entità Utente e la salva nel DB
		return "redirect:/"; // Dopo la registrazione, reindirizza alla home page "/"
	}

}
