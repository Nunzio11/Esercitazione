package com.generationitaly.progettofilm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.generationitaly.progettofilm.entity.Regista;

public interface RegistaRepository extends JpaRepository<Regista, Long> {

	// Cerca registi dove la stringa è contenuta nel nome+cognome o cognome+nome (in qualsiasi ordine)
	@Query("from Regista r where concat(r.nome, ' ',r.cognome) like %?1% or concat(r.cognome, ' ',r.nome) like %?1%")
	List<Regista> findRegistaByString(String string);

	// Come sopra, ma ordina i risultati per nome ascendente e cognome ascendente
	@Query("from Regista a where concat(a.nome, ' ', a.cognome) like %?1% or concat(a.cognome, ' ', a.nome) like %?1% order by a.nome asc, a.cognome asc")
	List<Regista> findRegistaByStringOrderByNomeAsc(String string);

	// Come sopra, ma ordina per nome ascendente e cognome discendente
	@Query("from Regista a where concat(a.nome, ' ', a.cognome) like %?1% or concat(a.cognome, ' ', a.nome) like %?1% order by a.nome asc, a.cognome desc")
	List<Regista> findRegistaByStringOrderByNomeDesc(String string);

	// Trova il regista associato a un film specifico dato l'id del film
	@Query("SELECT r FROM Regista r JOIN r.films f WHERE f.id =?1")
	Regista findByFilmId(Long filmId);
}
