package com.generationitaly.progettofilm.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity // Indica che questa classe è un'entità JPA (corrisponde a una tabella nel
		// database)
@Table(name = "film_attore", // Nome della tabella nel database
		uniqueConstraints = @UniqueConstraint(columnNames = { "film_id", "attore_id" })
// Impone che la coppia (film_id, attore_id) sia unica nella tabella
// Evita che lo stesso attore venga associato più volte allo stesso film
)
public class FilmAttore {

	@Id // Chiave primaria della tabella
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-incremento del campo ID
	@Column(name = "id") // Mappatura con la colonna "id" del DB
	private long id;

	@ManyToOne // Molti FilmAttore sono legati a un solo Film
	@JoinColumn(name = "film_id", nullable = false)
	// Colonna "film_id" come chiave esterna verso la tabella "film", obbligatoria
	private Film film;

	@ManyToOne // Molti FilmAttore sono legati a un solo Attore
	@JoinColumn(name = "attore_id", nullable = false)
	// Colonna "attore_id" come chiave esterna verso la tabella "attore",
	// obbligatoria
	private Attore attore;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Film getFilm() {
		return film;
	}

	public void setFilm(Film film) {
		this.film = film;
	}

	public Attore getAttore() {
		return attore;
	}

	public void setAttore(Attore attore) {
		this.attore = attore;
	}

	@Override
	public String toString() {
		return "FilmAttore [id=" + id + ", attore=" + attore + "]";
	}

}
