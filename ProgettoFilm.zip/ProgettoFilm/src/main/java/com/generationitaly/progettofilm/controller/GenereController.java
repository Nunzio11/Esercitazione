package com.generationitaly.progettofilm.controller;


import org.springframework.stereotype.Controller;


@Controller
public class GenereController {

}
