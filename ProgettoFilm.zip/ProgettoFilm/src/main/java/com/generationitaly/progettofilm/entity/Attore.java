package com.generationitaly.progettofilm.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

/*CREATE TABLE attore (
	    id BIGINT NOT NULL AUTO_INCREMENT,
	    foto TEXT,
	    nome VARCHAR(45) NOT NULL,
	    cognome VARCHAR(45) NOT NULL,
	    biografia TEXT,
	    PRIMARY KEY (id)
	);
*/

@Entity // Indica che questa classe rappresenta una tabella nel DB
@Table(name = "attore") // Nome della tabella nel database
public class Attore {

	@Id // Chiave primaria
	@GeneratedValue(strategy = GenerationType.IDENTITY) // ID generato automaticamente (AUTO_INCREMENT)
	@Column(name = "id") // Mappatura alla colonna "id"
	private long id;

	@Column(name = "foto", nullable = true) // Colonna "foto", può essere null
	private String foto;

	@Column(name = "nome", nullable = false, length = 45) // Colonna "nome", obbligatoria, max 45 caratteri
	private String nome;

	@Column(name = "cognome", nullable = false, length = 45) // Colonna "cognome", obbligatoria, max 45 caratteri
	private String cognome;

	@Column(name = "biografia", nullable = true, length = 10000) // Colonna "biografia", max 10.000 caratteri
	private String biografia;

	@OneToMany(mappedBy = "attore", fetch = FetchType.EAGER) // Relazione uno-a-molti con FilmAttore (caricata subito)
	private List<FilmAttore> filmAttore; // Lista dei film associati a questo attore

	// Getter e setter per ogni campo

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getBiografia() {
		return biografia;
	}

	public void setBiografia(String biografia) {
		this.biografia = biografia;
	}

	@Override
	public String toString() {
		return "Attore [id=" + id + ", foto=" + foto + ", nome=" + nome + ", cognome=" + cognome + ", biografia="
				+ biografia + "]";
	}

}
